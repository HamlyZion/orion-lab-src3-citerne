# Chronologie de la session Orion

_Session initialisée le 2026-11-05 11:34:33 UTC._

| Heure (UTC) | Événement | Détails |
| --- | --- | --- |
| `11:34:33` | **Ouverture de session** | Mode : GAMEDAY — Rôles : IC=Theo, Mitigator=Erwan, Investigator=Gilles, Second Investigator=Pierre |
| `11:40:30` | **Déclaration d'incident (warning)** | [ic] Dégradation du SLO de qualité sur les questions de référence (< 90 %) |
| `11:50:00` | **Déclaration d'incident (warning)** | [ic] Augmentation de requetes de l'équipe support et saturation du pool de connexion à la DB. Usage intensif de token et saturation de queue |
| `11:51:01` | **Alerte déclenchée : OrionQuotaEquipeRejetsTicket** | Rejets de quota (HTTP 429) pour l'équipe support |
| `11:56:31` | **Observation horodatée** | [investigator] Le quota de l'équipe support sur le nombre de requetes a explosé et génère un goulot d'étranglement sur les connexions à la database, dégradant la p95 du pool (`histogram_quantile(0.95, sum by (le) (rate(rag_db_pool_wait_seconds_bucket[5m]))) et sum by (team, backend) (rate(gateway_requests_total{team="support"}[5m]))`) |
| `12:09:09` | **Observation horodatée** | [mitigator] Une explosion de requetes avec le code 429 car le quota de l'équipe support est épuisé (`sum(rate(traefik_service_requests_total{service="rag@file", code!="429"}[5m]))`) |
| `12:09:09` | **Action de mitigation exécutée** | [mitigator] Délestage du trafic (pourcentage ou équipe) — Délester l'équipe support |
| `12:24:58` | **Cause racine déclarée** | [ic] L'équipe support envoyait trop de requetes et a épuisé son quota. En exercant un refus de requetes venant de leur côté on soulage la base de données qui voyait la p95 du pool de connexion augmenter. (`histogram_quantile(0.95, sum by (le) (rate(rag_db_pool_wait_seconds_bucket[5m]))) et sum(rate(traefik_service_requests_total{service="rag@file", code!="429"}[5m]))`) |
| `12:26:37` | **Clôture de l'incident** | [ic] Levier appliqué, retour à l'état normal. Le nombre de requetes initiées par l'équipe support reste élevé mais cela sort du scope d'actions que nous pouvons mener |
